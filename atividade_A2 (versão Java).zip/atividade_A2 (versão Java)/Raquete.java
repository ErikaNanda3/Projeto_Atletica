public class Raquete extends Objeto{
    private String tamanho;

     public Raquete(String nome, String tamanho){
        super(nome);
        this.tamanho = tamanho;
    }

    public String getTamanho(){
        return tamanho;
    }
    public void setTamanho(String tamanho){
        if(tamanho != null && !tamanho.isEmpty()){
            this.tamanho = tamanho;
        } else {
            throw new IllegalArgumentException("O nome não é válido, digite outro");
        }
    }

    @Override
    void prazoEmprestimo(){
        this.tempoEmprestimo = 2;
    };

}
    
