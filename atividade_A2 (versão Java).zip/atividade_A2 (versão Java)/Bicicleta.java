public class Bicicleta extends Objeto{
    private String tamanho;
    //dia dia ou aquelas mais robustas
    private String tipo;
    private boolean vistoria;

    public Bicicleta(String nome, String tamanho, String tipo){
        super(nome);
        this.tamanho = tamanho;
        this.tipo = tipo;
    }

     public String getTamanho(){
        return tamanho;
    }
    public String getCurso(){
        return tipo;
    }
    public void setTamanho(String tamanho){
        if(tamanho != null && !tamanho.isEmpty()){
            this.tamanho = tamanho;
        } else {
            throw new IllegalArgumentException("O tamanho não é válido, digite outro");
        }
    }
    public void setTipo(String tipo){
        if(tipo != null && !tipo.isEmpty()){
            this.tipo = tipo;
        } else {
            throw new IllegalArgumentException("O nome do curso não é válido, digite outro");
        }
    }

     public void naoFeitaVistoria(){
        this.vistoria = false;
    }
    public void feitaVistoria(){
        this.vistoria = true;
    }

    @Override
    void prazoEmprestimo(){
        this.tempoEmprestimo = 7;
    };

}
