public class Bola extends Objeto{
    //Mais viável especificar o tipo de esporte de cada bola
    //do que criar três classes novas
    private String esporte;

    public Bola(String nome, String esporte){
        super(nome);
        this.esporte = esporte;
    }

    public String getEsporte(){
        return esporte;
    }
    public void setEsporte(String esporte){
        if(esporte != null && !esporte.isEmpty()){
            this.esporte = esporte;
        } else {
            throw new IllegalArgumentException("O nome não é válido, digite outro");
        }
    }


    @Override
    void prazoEmprestimo(){
        this.tempoEmprestimo = 1;
    };



}
