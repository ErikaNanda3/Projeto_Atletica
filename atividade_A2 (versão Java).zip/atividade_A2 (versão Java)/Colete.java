public class Colete extends Objeto{
    private String tamanho;
    private String curso;

    public Colete(String nome, String tamanho, String curso){
        super(nome);
        this.tamanho = tamanho;
        this.curso = curso;
    }

     public String getTamanho(){
        return tamanho;
    }
    public String getCurso(){
        return curso;
    }
    public void setTamanho(String tamanho){
        if(tamanho != null && !tamanho.isEmpty()){
            this.tamanho = tamanho;
        } else {
            throw new IllegalArgumentException("O tamanho não é válido, digite outro");
        }
    }
    public void setCurso(String curso){
        if(curso != null && !curso.isEmpty()){
            this.curso = curso;
        } else {
            throw new IllegalArgumentException("O nome do curso não é válido, digite outro");
        }
    }

    @Override
    void prazoEmprestimo(){
        this.tempoEmprestimo = 1;
    };


}
