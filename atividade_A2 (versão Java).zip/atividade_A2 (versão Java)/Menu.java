import java.util.ArrayList;
import java.util.Scanner;

public class Menu {
    public static void main(String[] args) throws Exception {
     ArrayList<Usuario> pessoas = new ArrayList<>();
     ArrayList<Objeto> itens = new ArrayList<>();
     Scanner scanner = new Scanner(System.in);

     //preenche uma lista generica inicial com 12 pessoas
     //6 usam um método construtor e as outras usam outro (sobrecarga de construtores)
     pessoas.add(new Aluno("Nikolas", "999749390", "2927646"));
     pessoas.add(new Servidor("Marcelo", "994567398", "12983645268"));
     pessoas.add(new Aluno("Elisa", "998374635", "7463546"));
     pessoas.add(new Servidor("Talita", "992536472", "19273645733"));
     pessoas.add(new Aluno("Emilly", "996483748", "2923734"));
     pessoas.add(new Servidor("Fabio", "993546378", "34267895647"));
     pessoas.add(new Aluno("Matheus"));
     pessoas.add(new Servidor("Alisson"));
     pessoas.add(new Aluno("Hagatta"));
     pessoas.add(new Servidor("Ana"));
     pessoas.add(new Aluno("Gabriel"));
     pessoas.add(new Servidor("Larissa"));

     itens.add(new Bola("Bola de futsal", "futsal"));
     itens.add(new Bola("Bola de volei", "volei"));
     itens.add(new Bola("Bola de basquete", "basquete"));
     itens.add(new Raquete("Raquete de tenis 1", "A"));
     itens.add(new Raquete("Raquete de tenis 2", "B"));
     itens.add(new Colete("Colete Esportivo", "M", "Engenharia Quimica"));
     itens.add(new Colete("COlete Esportivo", "P", "Engenharia Eletrica"));
     itens.add(new Bicicleta("Bicicleta comum", "Grande", "comum"));
     itens.add(new Bicicleta("Bicicleta de Trilha", "Media", "Trilha"));

     int cod = 0;

     System.out.println("--Plataforma para Emprestimos de itens da Atlética do Campus da UTFPR de Apucarana ----");
     System.out.println("\n");
     do{
     System.out.println("----Digite 1 se já tem cadastro, 2 caso queira criar um, 3 para mostrar as fichas de empréstimos e 4 para sair: ----");
     try{
     cod = scanner.nextInt();   
     //recomendação para limpar o buffer
     scanner.nextLine();
     } catch (Exception e){
        System.out.println("Digite um numero válido");
        scanner.nextLine();
        continue;
     }
       switch(cod){
        case 1: 
            int b = 0;
            Usuario usuarioAtual = null;
            System.out.println("---Menu de Empréstimo---");
            System.out.println("\n");
            System.out.println("Digite o seu nome: ");
            String nomeDigitado = scanner.nextLine();
            for(Usuario p: pessoas){
                if (p.getNome().equalsIgnoreCase(nomeDigitado)) {
                            usuarioAtual = p;
                            break;
                        }
            }

            if(usuarioAtual == null){
                System.out.println("Nenhum nome referente a esse foi cadastrado");
            }
            System.out.println("---Digite 1 para ver sua ficha cadastral, 2 para realizar um novo empréstimo ou 3 para devolver um item---");
            b = scanner.nextInt();   
            switch(b){
                case 1:
                    System.out.println("Ficha: "+ usuarioAtual.ficha());
                    break;
                case 2:
                    System.out.println("Lista de itens disponiveis");
                        for (int i = 0; i < itens.size(); i++) {
                            Objeto obj = itens.get(i);
                            String dispo = obj.estaDisponivel() ? "Disponível " : "Indisponível ";
                            System.out.println((i + 1) + " - " + obj.getNome() + dispo );
                        }
                        System.out.print("Escolha o número do objeto que deseja emprestar: ");
                        int idObj = scanner.nextInt() - 1;
                        scanner.nextLine();

                        if (idObj >= 0 && idObj < itens.size()) {
                            Objeto objEscolhido = itens.get(idObj);
                            usuarioAtual.emprestar(objEscolhido);
                        } else {
                            System.out.println("Opção de objeto inválida.");
                        }
                    
                    break;
                case 3:
                       System.out.println("Lista de itens Emprestados");
                        System.out.print("Digite o nome exato do objeto que deseja devolver: ");
                        String nomeObjDev = scanner.nextLine();
                        
                        Objeto objDevolver = null;
                        for (Objeto o : itens) {
                            if (o.getNome().equalsIgnoreCase(nomeObjDev)) {
                                objDevolver = o;
                                break;
                            }
                        }
                        if (objDevolver != null) {
                            usuarioAtual.devolver(objDevolver);
                        } else {
                            System.out.println("Objeto não encontrado no sistema");
                        }
                    break;
                default:
                    System.out.println("Código inserido inválido\n");
                    break;
            }
            break;
        case 2:
            int a = 0;
            System.out.println("---Menu de Cadastro---");
            System.out.println("\n");
            System.out.println("Digite 1 se for servidor ou 2 se for aluno:");
            a = scanner.nextInt();   
            switch(a){
                case 1:
                   System.out.println("\n");
                   System.out.println("Digite o seu nome: \n");
                   String nome = scanner.nextLine();
                   System.out.println("Digite o seu id: \n");
                   String id = scanner.nextLine();
                   System.out.println("Digite o seu numero de telefone para contato: \n");
                   String telefone = scanner.nextLine();

                   try {
                    pessoas.add(new Servidor(nome, telefone, id));
                    System.out.println("Servidore cadastrado com sucesso!");
                   } catch(IllegalArgumentException e){
                    System.out.println("Erro no cadastro, tente novamente.");
                   }

                   break;

                case 2:
                    System.out.println("\n");
                   System.out.println("Digite o seu nome: \n");
                   String nome1 = scanner.nextLine();
                   System.out.println("Digite o seu ra: \n");
                   String ra = scanner.nextLine();
                   System.out.println("Digite o seu numero de telefone para contato: \n");
                   String telefone1 = scanner.nextLine();

                   try {
                    pessoas.add(new Servidor(nome1, telefone1, ra));
                    System.out.println("Aluno cadastrado com sucesso!");
                   } catch(IllegalArgumentException e){
                    System.out.println("Erro no cadastro, tente novamente.");
                   }
                   break;
                   default:
                    break;
        }
            break;
        case 3: 
             for(Usuario p : pessoas){
             System.out.println(p.ficha());
            }
             break;
     
        case 4:
            System.out.println("Você encerrou sua sessão!");
            break;
        default: 
            System.out.println("Código inválido");
            break;

        }
     } while(cod != 4);

     scanner.close();
}   
    }
