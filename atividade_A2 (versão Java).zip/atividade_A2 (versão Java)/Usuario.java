import java.util.ArrayList;

abstract class Usuario {
    private String nome = " ";
    //em string para garantir o tamanho exato de 9
    private String numTelefone;
    private int penalidade = 0;
    protected int qtdEmprestimo;
    

    private ArrayList<Objeto> itensEmprestados;

    public Usuario(String nome, String numTelefone){
        this(nome);
        setNumTelefone(numTelefone);
        this.itensEmprestados = new ArrayList<>();
    }
    public Usuario(String nome){
        setNome(nome);
    }

    public int getQtdEmprestimo(){
        return qtdEmprestimo;
    }

    public String getNome(){
        return nome;
    }
    public String getNumTelefone(){
        return numTelefone;
    }
     public int getPenalidade(){
        return penalidade;
    }

    public void setNome(String nome){
        if(nome != null && !nome.isEmpty()){
            this.nome = nome;
        } else {
            throw new IllegalArgumentException("O nome não é válido, digite outro");
        }
    }

     public void setNumTelefone(String numTelefone){
        if(numTelefone != null && numTelefone.matches("\\d{9}")){
            this.numTelefone = numTelefone;
        } else {
             throw new IllegalArgumentException("O número deve conter 9 dígitos para ser válido");
        }
    }

    public void setPenalidade(int penalidade){
        this.penalidade = penalidade;
    }

     String ficha(){
        return nome + " telefone: " + numTelefone;
    }

    public boolean podeEmprestar(){
        return penalidade < 5;
    }

    //para emprestar um objeto existe algusn requisitos:
    //o objeto precisa estar disponível, a pessoa não pode estar excluida de emprestar(penalidade = 5)
    //e não pode ultrapassar o limite de emprestimo dela mesma
     public boolean emprestar(Objeto objeto){
        if(!objeto.estaDisponivel()){
            System.out.println("Objeto indisponível\n");
            return false;
        }
        if(penalidade >= 5){
            System.out.println("Pessoa suspensa de emprestar\n");
            return false;
        }
        if(this.itensEmprestados.size() >= this.qtdEmprestimo){
            System.out.println("Limite de empréstimo alcançado, não é possível pegar mais itens\n");
            return false;
        }

        objeto.emprestado();
        this.itensEmprestados.add(objeto);
        System.out.println("Empréstimo feito com sucessor!\n");
        return true;
     }

     //para devolver um item, é preciso verificar se o usuario realmente pegou o item
     //e se o item foi devolvido com atraso (?)
     public boolean devolver(Objeto objeto){
        
        if(this.itensEmprestados.contains(objeto)){
            objeto.disponivel();
            this.itensEmprestados.remove(objeto);
            System.out.println("Devolução feita com sucesso!\n");
            return true;
        } else{
            System.out.println("Não há objeto emprestado referente ao informado\n");
            return false;
        }
     }

     
    
    
}
