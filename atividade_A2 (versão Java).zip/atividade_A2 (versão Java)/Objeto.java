abstract class Objeto {
    private String nome;
    private boolean disponivel = true;
    protected int tempoEmprestimo;

    public Objeto(String nome){
        this.nome = nome;
    }

    public void emprestado(){
        this.disponivel = false;
    }
    public void disponivel(){
        this.disponivel = true;
    }

    public boolean estaDisponivel(){
        return disponivel;
    }

    public String getNome(){
        return nome;
    }

     public void setNome(String nome){
        if(nome != null && !nome.isEmpty()){
            this.nome = nome;
        } else {
            throw new IllegalArgumentException("O nome não é válido, digite outro");
        }
    }

    public int getTempoEmprestimo(){
        return tempoEmprestimo;
    }

     abstract void prazoEmprestimo();

}
