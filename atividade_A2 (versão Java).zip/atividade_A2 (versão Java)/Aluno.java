public class Aluno extends Usuario {
    private String ra;

    public Aluno(String nome, String numTelefone, String ra){
        super(nome, numTelefone);
        setRa(ra);
        this.qtdEmprestimo = 3;
    }
    public Aluno(String nome){
        super(nome);
    }

    public String getRa(){
        return ra;
    }
     public void setRa(String ra){
        if(ra != null && ra.matches("\\d{7}")){
            this.ra = ra;
        } else {
             throw new IllegalArgumentException("O Ra deve conter 7 dígitos para ser válido");
        }
    }

    @Override
     String ficha(){
        return super.ficha() + ", Ra: " + ra;
     }
    
}
