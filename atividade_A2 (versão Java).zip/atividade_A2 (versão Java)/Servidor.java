public class Servidor extends Usuario{
    private String id;

    public Servidor(String nome, String numTelefone, String id){
        super(nome, numTelefone);
        setId(id);
        this.qtdEmprestimo = 5;
    }
    public Servidor(String nome){
        super(nome);
    }

     public String getId(){
        return id;
    }
     public void setId(String id){
        if(id != null && id.matches("\\d{11}")){
            this.id = id;
        } else {
             throw new IllegalArgumentException("O Id deve conter 11 dígitos para ser válido");
        }
    }

    @Override
     String ficha(){
        return super.ficha() + ", Id: " + id;
     }
    
    }
